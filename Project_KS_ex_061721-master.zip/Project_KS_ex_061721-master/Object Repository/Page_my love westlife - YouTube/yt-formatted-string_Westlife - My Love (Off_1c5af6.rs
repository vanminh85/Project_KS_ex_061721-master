<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>yt-formatted-string_Westlife - My Love (Off_1c5af6</name>
   <tag></tag>
   <elementGuidId>690da1ef-cfa3-489d-833d-0481bddf9833</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='video-title']/yt-formatted-string</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>yt-formatted-string.style-scope.ytd-video-renderer</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>yt-formatted-string</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>style-scope ytd-video-renderer</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Westlife - My Love (Official Video) by Westlife 11 years ago 4 minutes, 14 seconds 263,127,319 views</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Westlife - My Love (Official Video)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;page-manager&quot;)/ytd-search[@class=&quot;style-scope ytd-page-manager&quot;]/div[@id=&quot;container&quot;]/ytd-two-column-search-results-renderer[@class=&quot;style-scope ytd-search&quot;]/div[@id=&quot;primary&quot;]/ytd-section-list-renderer[@class=&quot;style-scope ytd-two-column-search-results-renderer&quot;]/div[@id=&quot;contents&quot;]/ytd-item-section-renderer[@class=&quot;style-scope ytd-section-list-renderer&quot;]/div[@id=&quot;contents&quot;]/ytd-video-renderer[@class=&quot;style-scope ytd-item-section-renderer&quot;]/div[@id=&quot;dismissible&quot;]/div[@class=&quot;text-wrapper style-scope ytd-video-renderer&quot;]/div[@id=&quot;meta&quot;]/div[@id=&quot;title-wrapper&quot;]/h3[@class=&quot;title-and-badge style-scope ytd-video-renderer&quot;]/a[@id=&quot;video-title&quot;]/yt-formatted-string[@class=&quot;style-scope ytd-video-renderer&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='video-title']/yt-formatted-string</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to queue'])[1]/following::yt-formatted-string[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Westlife'])[1]/preceding::yt-formatted-string[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Westlife - My Love (Official Video)']/parent::*</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/h3/a/yt-formatted-string</value>
   </webElementXpaths>
</WebElementEntity>
