<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_A8SBwfpositionrelativemargin0 autopaddi_f6c27f</name>
   <tag></tag>
   <elementGuidId>42554b29-f9b7-493b-ac66-15aab9b37322</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/following::div[10]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>form > div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>jsmodel</name>
      <type>Main</type>
      <value>vWNDde</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>jsdata</name>
      <type>Main</type>
      <value>MuIEvd;_;AUXk6E</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> .A8SBwf{position:relative;margin:0 auto;padding-top:6px;width:484px;width:auto;max-width:484px;}#searchform.big .A8SBwf{width:584px;width:auto;max-width:584px}.A8SBwf{width:auto;max-width:584px}.RNNXgb{background:#fff;display:flex;border:1px solid #dfe1e5;box-shadow:none;border-radius:24px;z-index:3;height:44px;margin:0 auto;width:482px;width:auto;}.minidiv .RNNXgb{background:#fff;height:32px;border-radius:16px;margin:10px 0 0}.emcav .RNNXgb{border-bottom-left-radius:0;border-bottom-right-radius:0;border-color:rgba(223,225,229,0);box-shadow:0 1px 6px rgba(32,33,36,.28)}.minidiv .emcav .RNNXgb{border-bottom-left-radius:0;border-bottom-right-radius:0}.emcav.emcat .RNNXgb{border-bottom-left-radius:24px;border-bottom-right-radius:24px}.minidiv .emcav.emcat .RNNXgb{border-bottom-left-radius:16px;border-bottom-right-radius:16px}.RNNXgb:hover,.sbfc .RNNXgb{background-color:#fff;box-shadow:0 1px 6px rgba(32,33,36,.28);border-color:rgba(223,225,229,0)}.UUbT9{width:auto}#searchform.big .RNNXgb{width:582px;width:auto}.RNNXgb{width:auto;max-width:584px}.SDkEP{flex:1;display:flex;padding:5px 8px 0 16px;padding-left:14px}.minidiv .SDkEP{padding-top:0}.FPdoLc{padding-top:18px;top:53px;z-index:0;}#searchform.big .FPdoLc{}.iblpc{display:flex;align-items:center;padding-right:13px;margin-top:-5px}.minidiv .iblpc{margin-top:0}.CcAdNb{margin:auto}.QCzoEc{margin-top:3px;color:#9aa0a6;height:20px;width:20px}.gLFyf{background-color:transparent;border:none;margin:0;padding:0;color:rgba(0,0,0,.87);word-wrap:break-word;outline:none;display:flex;flex:100%;-webkit-tap-highlight-color:transparent;margin-top:-37px;height:34px;font-size:16px}.minidiv .gLFyf{margin-top:-35px;}.a4bIc{display:flex;flex:1;flex-wrap:wrap}.pR49Ae{color:transparent;flex:100%;white-space:pre;height:34px}.pR49Ae span{background:url(&quot;/images/experiments/wavy-underline.png&quot;) repeat-x scroll 0 100% transparent;padding:0 0 10px 0;}.dRYYxd{display:flex;flex:0 0 auto;margin-top:-5px;align-items:stretch;flex-direction:row}.minidiv .dRYYxd{margin-top:0} .BKRPef{flex:1 0 auto;display:none;cursor:pointer;align-items:center;border:0;background:transparent;outline:none;padding:0 8px;line-height:44px}.M2vV3{display:flex}.ExCKkf{height:100%;color:#70757a;vertical-align:middle;outline:none}.minidiv .BKRPef{line-height:32px}.minidiv .ExCKkf{width:20px} .BKRPef{padding-right:4px}.ExCKkf{margin-right:12px}.ACRAdd{border-left:1px solid #dfe1e5;height:65%}     .Umvnrc{flex:1 0 auto;display:flex;cursor:pointer;align-items:center;border:0;background:transparent;outline:none;padding:0 8px;width:24px;line-height:44px}.ly0Ckb{background:url('//www.gstatic.com/inputtools/images/tia.png') no-repeat center;height:24px;width:24px;vertical-align:middle}.yAnw3c{visibility:hidden}.XDyW0e{flex:1 0 auto;display:flex;cursor:pointer;align-items:center;border:0;background:transparent;outline:none;padding:0 8px;width:24px;line-height:44px}.goxjub{height:24px;width:24px;vertical-align:middle}.minidiv .XDyW0e{line-height:32px}.minidiv .goxjub{width:20px;height:20px}.UUbT9{position:absolute;width:100%;text-align:left;margin-top:-1px;z-index:3;cursor:default;-webkit-user-select:none}.aajZCb{background:#fff;box-shadow:0 4px 6px rgba(32,33,36,.28);display:flex;flex-direction:column;list-style-type:none;margin:0;padding:0;border:0;border-radius:0 0 24px 24px;padding-bottom:4px;overflow:hidden}.minidiv .aajZCb{border-bottom-left-radius:16px;border-bottom-right-radius:16px}.erkvQe{flex:auto;padding-bottom:8px;}.RjPuVb{height:1px;margin:0 26px 0 0}.S3nFnd{display:flex}.S3nFnd .RjPuVb,.S3nFnd .aajZCb{flex:0 0 auto}.lh87ke:link,.lh87ke:visited{color:#1a0dab;cursor:pointer;font:11px arial,sans-serif;padding:0 5px;margin-top:-10px;text-decoration:none;flex:auto;align-self:flex-end;margin:0 16px 5px 0}.lh87ke:hover{text-decoration:underline}.xtSCL{border-top:1px solid #e8eaed;margin:0 20px 0 14px;padding-bottom:4px}.sb7{background:url() no-repeat ;min-height:0px;min-width:0px;height:0px;width:0px}.sb27{background:url(/images/searchbox/desktop_searchbox_sprites318_hr.webp) no-repeat 0 -21px;background-size:20px;min-height:20px;min-width:20px;height:20px;width:20px}.sb43{background:url(/images/searchbox/desktop_searchbox_sprites318_hr.webp) no-repeat 0 0;background-size:20px;min-height:20px;min-width:20px;height:20px;width:20px}.sb53.sb53{padding:0 4px;margin:0}30shineXóa3Bài hát của Britney SpearsXóa3utoolsXóa30/4 là ngày gìXóa3kingXóa30/4Xóa365 Ngày Yêu AnhPhim 2020Xóa3107Bài hát của DuonggXóa3dwarehouseXóa3ceXóa#ynRric{display:none}.ynRric{list-style-type:none;flex-direction:column;color:#70757a;font-family:Google Sans,arial,sans-serif-medium,sans-serif;font-size:14px;margin:0 20px 0 16px;padding:8px 0 8px 0;line-height:16px}#YMXe{display:none}.sbct{display:flex;align-items:center;min-width:0;padding:0}.eIPGRd{flex:auto;display:flex;align-items:center;margin:0 20px 0 14px}.pcTkSc{display:flex;flex:auto;flex-direction:column;min-width:0;padding:6px 0}.sbic{display:flex;align-items:center;margin:0 13px 0 1px;}.sbic.vYOkbe{margin:4px 7px 4px -5px;border-radius:4px;min-height:32px;min-width:32px;background:center/contain no-repeat}.sbre .wM6W7d{line-height:18px}.ClJ9Yb{line-height:12px;font-size:13px;color:#80868b;margin-top:2px}.wM6W7d{display:flex;font-size:16px;color:#212121;flex:auto;align-items:center;word-break:break-word;padding-right:8px}.minidiv .wM6W7d{font-size:14px}.WggQGd{color:#52188c}.wM6W7d span{flex:auto}.AQZ9Vd{display:flex;align-self:stretch}.JCHpcb:hover{color:#1a73e8;text-decoration:underline;}.JCHpcb{color:#80868b;font:13px arial,sans-serif;cursor:pointer;align-self:center}.sbhl{background:#eee}.mus_pc{display:block;margin:6px 0}.mus_il{font-family:Arial,HelveticaNeue-Light,HelveticaNeue,Helvetica;padding-top:7px;position:relative}.mus_il:first-child{padding-top:0}.mus_il_at{margin-left:10px}.mus_il_st{right:52px;position:absolute}.mus_il_i{align:left;margin-right:10px}.mus_it3{margin-bottom:3px;max-height:24px;vertical-align:bottom}.mus_it5{height:24px;width:24px;vertical-align:bottom;margin-left:10px;margin-right:10px;transform:rotate(90deg)}.mus_tt3{color:#767676;font-size:12px;vertical-align:top}.mus_tt5{color:#dd4b39;font-size:14px}.mus_tt6{color:#3d9400;font-size:14px}.mus_tt8{font-size:16px;font-family:Arial,sans-serif}.mus_tt17{color:#212121;font-size:20px}.mus_tt18{color:#212121;font-size:24px}.mus_tt19{color:#767676;font-size:12px}.mus_tt20{color:#767676;font-size:14px}.mus_tt23{color:#767676;font-size:18px}Xóa .lJ9FBc{height:70px}.lJ9FBc input[type=&quot;submit&quot;],.gbqfba{background-color:#f8f9fa;border:1px solid #f8f9fa;border-radius:4px;color:#3c4043;font-family:arial,sans-serif;font-size:14px;margin:11px 4px;padding:0 16px;line-height:27px;height:36px;min-width:54px;text-align:center;cursor:pointer;user-select:none}.lJ9FBc input[type=&quot;submit&quot;]:hover{box-shadow:0 1px 1px rgba(0,0,0,.1);background-color:#f8f9fa;border:1px solid #dadce0;color:#202124}.lJ9FBc input[type=&quot;submit&quot;]:focus{border:1px solid #4285f4;outline:none}      .JUypV{font-size:8pt;margin-top:-16px;position:absolute;right:16px}a.oBa0Fe{color:#70757a;float:right;font-style:italic;-webkit-tap-highlight-color:rgba(0,0,0,.00);tap-highlight-color:rgba(0,0,0,.00)}a.aciXEb{padding:0 5px;}.RTZ84b{color:#70757a;cursor:pointer;padding-right:8px}.XEKxtf{color:#70757a;float:right;font-size:12px;line-height:1.34;padding-bottom:4px}Báo cáo các gợi ý không phù hợp          </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;L3eUgb&quot;]/div[@class=&quot;o3j99 ikrT4e om7nvf&quot;]/form[1]/div[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/following::div[10]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đăng nhập'])[1]/following::div[15]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div</value>
   </webElementXpaths>
</WebElementEntity>
