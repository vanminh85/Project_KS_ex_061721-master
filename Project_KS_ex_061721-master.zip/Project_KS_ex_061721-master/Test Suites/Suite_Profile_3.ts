<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Profile_3</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>5e813c9d-ff5b-4234-8f0f-d861b49ef5b7</testSuiteGuid>
   <testCaseLink>
      <guid>89596b92-b44e-4510-a73c-db8fa18f15ce</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC001_Profile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d9ad35fd-7a8c-4d13-bead-4540e45b3dde</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC002_Profile</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
