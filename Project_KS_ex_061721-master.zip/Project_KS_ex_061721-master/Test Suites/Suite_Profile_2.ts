<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Suite_Profile_2</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c2925f26-c095-4511-906a-e9c91e7f150a</testSuiteGuid>
   <testCaseLink>
      <guid>d9ad35fd-7a8c-4d13-bead-4540e45b3dde</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC002_Profile</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5a2be08b-d398-448f-8977-6090b6bf5bb5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC2-văn minh-fail</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
