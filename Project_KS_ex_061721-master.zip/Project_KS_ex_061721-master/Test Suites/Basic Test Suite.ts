<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Basic Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>16e35ada-e44c-4215-9957-2aa516377b5b</testSuiteGuid>
   <testCaseLink>
      <guid>6779d5ca-7f92-4553-895c-2ac009f9d107</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2a3ffcf9-392d-4a7c-9ed5-2dbc84decd9e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC2-văn minh-fail</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ab4a7712-f3f7-4640-a446-b36580af87c5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC3_Россия_pass</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
