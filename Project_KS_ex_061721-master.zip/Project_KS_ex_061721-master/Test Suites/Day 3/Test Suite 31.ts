<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 31</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>45bcdc6a-cfe1-4786-be38-6f969af03728</testSuiteGuid>
   <testCaseLink>
      <guid>84ca4fb1-58c7-4d0b-a51d-c61c2f2c5b8a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.cal.pic.video/TC_google_calculate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e71d8d96-0933-4032-b5f4-6727b9de917e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.cal.pic.video/TC_google_picture</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
