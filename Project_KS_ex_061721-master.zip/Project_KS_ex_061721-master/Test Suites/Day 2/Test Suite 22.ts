<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 22</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4eb88513-5ef3-4d05-8e44-edfb8d7dff6b</testSuiteGuid>
   <testCaseLink>
      <guid>e15ae969-de2f-4987-ba9a-d2e4dbbfd935</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC2-văn minh-fail</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9e87930f-8484-48b6-90b3-7ae56925e1a0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC3_Россия_pass</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
