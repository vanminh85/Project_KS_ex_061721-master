<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 21</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>31359953-c273-416a-be71-31c5309b53af</testSuiteGuid>
   <testCaseLink>
      <guid>ca736b07-1d26-4140-95f6-dbe8e66f6512</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.cal.pic.video/TC_google_calculate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fc2e2c17-6fdc-48d0-946b-1ba870064104</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.cal.pic.video/TC_google_picture</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
