<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 1-信息技术</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>d2130b62-11a7-4394-a9d7-bde0abb4a394</testSuiteGuid>
   <testCaseLink>
      <guid>cd60c1d8-b717-4ad1-91e1-8a4fa025d018</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>904d1cd9-9072-4bac-8dc7-0147b0a6e9ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC2-văn minh-fail</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>58f29b89-0e5e-4c69-a0a2-959975decc87</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC1-信息技术 pass</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
