<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite 1</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>1a55799f-2383-4f77-bd00-cea7e204e8bf</testSuiteGuid>
   <testCaseLink>
      <guid>cd60c1d8-b717-4ad1-91e1-8a4fa025d018</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>904d1cd9-9072-4bac-8dc7-0147b0a6e9ef</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/TC.Name.Special.Letter/TC2-văn minh-fail</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
